<html>
<head>
	<title>Masik oldal</title>
</head>
<body>
<h1>Ez az erkezesi oldal</h1>
<?php 
if ($_POST["nev"] == "Cser Lajos")
{
	echo "Demonstrator";
}
else
{
	echo "Szia " . $_POST["nev"];
}

?>
</body>
</html>

