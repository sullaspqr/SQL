<html>
<head>
	<title>Tesztoldal</title>
</head>
<body>
<form action="udvozol.php" method="post">
<ul>
<li> Név: <input type="text" name="nev" /> </li>
</ul>
<input type="submit" />
</form>
</body>
</html>
