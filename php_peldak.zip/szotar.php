<html>
<head>
	<title>Szotar</title>
</head>
<body>
<form action="fordit.php" method="get">
<ul>
<li> Enter a word: <input type="text" name="word" /> </li>
</ul>
<input type="submit" value="Find"/>
</form>
</body>
</html>