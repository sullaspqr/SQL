<html>
<head>
	<title>Szotar</title>
</head>
<body>
<h1>Tal&aacute;latok</h1>
<?php 
$szotar = array("one" => "egy", "two" => "kett&otilde;",
				"dog" => "kutya", "apple" => "alma");
$keresett_szo = $_GET["word"];
if (isset($szotar[$keresett_szo])) 
	$talalt_szo = $szotar[$keresett_szo];
if (isset($talalt_szo))
{
	$valasz = $keresett_szo . ": " . $talalt_szo;
	echo $valasz;
}
else
{
	$valasz = "Nincs tal&aacute;lat";
	echo $valasz;
}

?>
</body>
</html>

